import React, { useState, useEffect, useRef } from 'react';
import { 
  Users, 
  Briefcase, 
  FileText, 
  CheckCircle,
  Clock,
  TrendingUp,
  Calendar,
  Award,
  BarChart3,
  ArrowUpRight,
  Plus,
  Filter,
  Search,
  MoreVertical,
  Zap,
  Loader,
  RefreshCw,
  AlertCircle,
  Target,
  Brain,
  Sparkles,
  Activity,
  MapPin,
  DollarSign,
  Eye,
  Download,
  UserCheck,
  Database,
  Wifi
} from 'lucide-react';

// API Configuration
const API_CONFIG = {
  BASE_URL: 'https://selective-consumers-boards-expenses.trycloudflare.com',
  API_KEY: 'sk-hiring-bot-2024-secret-key-xyz789',
};

const EnhancedDashboard = ({ userRole = 'hr' }) => {
  // State management
  const [dashboardData, setDashboardData] = useState(null);
  const [recentApplications, setRecentApplications] = useState([]);
  const [topJobs, setTopJobs] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [healthStatus, setHealthStatus] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  
  // Refs
  const mountedRef = useRef(true);
  const intervalRef = useRef(null);

  // Enhanced API call helper with better error handling
  const makeAPICall = async (endpoint, options = {}) => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // Increased timeout

    try {
      console.log(`🌐 API Call: ${API_CONFIG.BASE_URL}${endpoint}`);
      
      const response = await fetch(`${API_CONFIG.BASE_URL}${endpoint}`, {
        method: 'GET',
        headers: {
          'X-API-Key': API_CONFIG.API_KEY,
          'ngrok-skip-browser-warning': 'true',
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          ...options.headers
        },
        signal: controller.signal,
        ...options
      });

      clearTimeout(timeoutId);
      
      console.log(`📡 Response Status: ${response.status}`);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText}`);
      }

      const data = await response.json();
      console.log(`✅ API Success:`, data);
      return data;
      
    } catch (err) {
      clearTimeout(timeoutId);
      console.error(`❌ API Error:`, err);
      
      if (err.name === 'AbortError') {
        throw new Error('Request timeout - API took too long to respond');
      }
      
      if (err.message.includes('Failed to fetch')) {
        throw new Error('Cannot connect to API - Check if backend is running and accessible');
      }
      
      throw err;
    }
  };

  // Test API Connection
  const testAPIConnection = async () => {
    try {
      console.log('🔍 Testing API connection...');
      const healthResponse = await makeAPICall('/api/health');
      console.log('✅ Health check passed:', healthResponse);
      return true;
    } catch (error) {
      console.error('❌ API Test Failed:', error.message);
      return false;
    }
  };

  // Fetch dashboard data
  const fetchDashboardData = async () => {
    try {
      // Try to fetch dashboard endpoint first
      try {
        const data = await makeAPICall('/api/dashboard');
        if (data.success) {
          setDashboardData(data.data);
          setRecentApplications(data.data.recent_applications || []);
          setTopJobs(data.data.top_jobs || []);
          setStats(data.data.stats || {});
          setLastUpdated(new Date());
          setError(null);
          return;
        }
      } catch (dashboardError) {
        console.log('Dashboard endpoint not available, using individual endpoints');
      }

      // Fallback to individual endpoints
      await Promise.all([
        fetchStats(),
        fetchApplicationsStatus(),
        fetchJobsData()
      ]);
      
    } catch (err) {
      setError(`Dashboard data fetch failed: ${err.message}`);
    }
  };

  // Fetch platform statistics
  const fetchStats = async () => {
    try {
      const data = await makeAPICall('/api/stats');
      if (data.success && data.data && data.data.overall) {
        setStats(data.data.overall);
      }
    } catch (err) {
      console.error('Stats fetch failed:', err);
      // Create mock stats if API fails
      setStats({
        total_tickets: 0,
        approved_jobs: 0,
        pending_approval: 0,
        terminated_jobs: 0,
        total_applications: 0,
        total_hired: 0
      });
    }
  };

  // Check API health
  const checkHealth = async () => {
    try {
      const data = await makeAPICall('/api/health');
      setHealthStatus(data);
    } catch (err) {
      setHealthStatus({ status: 'error', message: err.message });
    }
  };

  // Fetch applications status data
  const fetchApplicationsStatus = async () => {
    try {
      const data = await makeAPICall('/api/applications/status?per_page=10');
      if (data.success) {
        const formattedApps = data.data.applications.map(app => ({
          id: app.id,
          candidateName: app.applicant_name,
          email: app.applicant_email,
          jobTitle: app.job_title,
          appliedDate: formatDate(app.uploaded_at),
          status: app.status,
          location: app.location,
          experience: `${app.experience_years || 'N/A'} years`,
          phone: app.applicant_phone
        }));
        setRecentApplications(formattedApps);
      }
    } catch (err) {
      console.error('Applications fetch failed:', err);
      // Set empty array if fetch fails
      setRecentApplications([]);
    }
  };

  // Fetch jobs data for dashboard
  const fetchJobsData = async () => {
    try {
      const data = await makeAPICall('/api/jobs/approved?per_page=5');
      if (data.success && data.data.jobs) {
        const formattedJobs = data.data.jobs.map(job => ({
          id: job.ticket_id,
          title: job.job_title,
          department: job.location,
          applications: Math.floor(Math.random() * 20) + 1, // Mock application count
          location: job.location,
          employmentType: job.employment_type,
          salaryRange: job.salary_range,
          requiredSkills: job.required_skills
        }));
        setTopJobs(formattedJobs);
      }
    } catch (err) {
      console.error('Jobs fetch failed:', err);
      // Set empty array if fetch fails
      setTopJobs([]);
    }
  };

  // Refresh all data
  const handleRefresh = async () => {
    setRefreshing(true);
    setError(null);
    try {
      // Test connection first
      const isConnected = await testAPIConnection();
      if (!isConnected) {
        throw new Error('Cannot connect to backend API. Please check if the server is running.');
      }

      await Promise.all([
        fetchDashboardData(),
        checkHealth()
      ]);
    } catch (err) {
      setError(`Refresh failed: ${err.message}`);
    } finally {
      setRefreshing(false);
    }
  };

  // Format date utility
  const formatDate = (dateString) => {
    if (!dateString) return 'Not specified';
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return dateString;
    }
  };

  // Get status color helper
  const getStatusColor = (status) => {
    switch(status) {
      case 'hired': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'under_review': return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'interview_scheduled': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'rejected': return 'bg-red-50 text-red-700 border-red-200';
      default: return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  // Get status icon helper
  const getStatusIcon = (status) => {
    switch(status) {
      case 'hired': return <CheckCircle className="w-3 h-3" />;
      case 'under_review': return <Clock className="w-3 h-3" />;
      case 'interview_scheduled': return <Calendar className="w-3 h-3" />;
      case 'rejected': return <AlertCircle className="w-3 h-3" />;
      default: return <FileText className="w-3 h-3" />;
    }
  };

  // Component lifecycle
  useEffect(() => {
    mountedRef.current = true;
    
    const initializeDashboard = async () => {
      setLoading(true);
      try {
        // Test connection first
        const isConnected = await testAPIConnection();
        if (!isConnected) {
          throw new Error('Cannot connect to backend API. Please check if the server is running.');
        }

        await Promise.all([
          fetchDashboardData(),
          checkHealth()
        ]);
      } catch (err) {
        setError(`Dashboard initialization failed: ${err.message}`);
      } finally {
        if (mountedRef.current) {
          setLoading(false);
        }
      }
    };

    initializeDashboard();

    // Auto-refresh interval
    intervalRef.current = setInterval(() => {
      if (!error && !loading && !refreshing) {
        fetchStats();
        fetchApplicationsStatus();
        checkHealth();
      }
    }, 60000); // Refresh every minute

    return () => {
      mountedRef.current = false;
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  // Calculate dashboard statistics
  const calculateStats = () => {
    const totalJobs = stats?.approved_jobs || topJobs.length;
    const totalApplications = stats?.total_applications || recentApplications.length;
    const totalHired = stats?.total_hired || recentApplications.filter(app => app.status === 'hired').length;
    const pendingCount = recentApplications.filter(app => app.status === 'under_review').length;

    return [
      {
        title: "Total Jobs",
        value: totalJobs,
        icon: Briefcase,
        gradient: "from-blue-500 to-blue-600",
        change: "+12%",
        trend: "up",
        subtitle: "Active positions"
      },
      {
        title: "Applications",
        value: totalApplications,
        icon: FileText,
        gradient: "from-emerald-500 to-emerald-600",
        change: "+8%",
        trend: "up",
        subtitle: "This month"
      },
      {
        title: "Hired",
        value: totalHired,
        icon: CheckCircle,
        gradient: "from-purple-500 to-purple-600",
        change: "+23%",
        trend: "up",
        subtitle: "New hires"
      },
      {
        title: "Pending",
        value: pendingCount,
        icon: Clock,
        gradient: "from-orange-500 to-orange-600",
        change: "-5%",
        trend: "down",
        subtitle: "In review"
      },
    ];
  };

  const dashboardStats = calculateStats();

  // Filter applications based on search
  const filteredApplications = recentApplications.filter(app =>
    app.candidateName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    app.jobTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
    app.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <div className="text-center">
          <Loader className="w-12 h-12 animate-spin mx-auto text-blue-600 mb-4" />
          <h3 className="text-xl font-semibold text-gray-800 mb-2">Loading HR Dashboard</h3>
          <p className="text-gray-600">🤖 Initializing AI-powered analytics...</p>
          <p className="text-sm text-gray-500 mt-2">Testing API connection...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 min-h-screen p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header Section */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                AI-Powered HR Dashboard
              </h1>
              <Sparkles className="w-6 h-6 text-purple-600" />
            </div>
            <p className="text-lg text-gray-600 max-w-2xl">
              Welcome back! Here's your complete overview of recruitment activities powered by advanced analytics.
            </p>
            {lastUpdated && (
              <p className="text-sm text-gray-500">
                Last updated: {lastUpdated.toLocaleTimeString()}
                {stats && ` • ${stats.total_applications || 0} total applications`}
              </p>
            )}
          </div>
          
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search candidates..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm w-64"
              />
            </div>
            <button
              onClick={handleRefresh}
              disabled={refreshing || loading}
              className="px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl transition-colors flex items-center gap-2 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
            <button className="px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl hover:from-blue-600 hover:to-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add Job
            </button>
          </div>
        </div>

        {/* Health Status */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className={`p-4 rounded-xl ${
            error 
              ? 'bg-red-100 border border-red-300' 
              : 'bg-green-100 border border-green-300'
          }`}>
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${
                error ? 'bg-red-500' : 'bg-green-500'
              }`}></div>
              <span className={`font-medium ${
                error ? 'text-red-700' : 'text-green-700'
              }`}>
                {error ? 'API Connection Issues' : 'API Connected'}
              </span>
            </div>
            <div className={`text-sm mt-1 ${error ? 'text-red-600' : 'text-green-600'}`}>
              <p>{error || 'All systems operational'}</p>
              <p className="text-xs mt-1">URL: {API_CONFIG.BASE_URL}</p>
            </div>
          </div>
          
          <div className={`p-4 rounded-xl ${
            healthStatus?.status === 'ok' 
              ? 'bg-green-100 border border-green-300'
              : 'bg-yellow-100 border border-yellow-300'
          }`}>
            <div className="flex items-center space-x-2">
              <Database className="w-4 h-4 text-blue-600" />
              <span className="font-medium text-gray-700">Database Status</span>
            </div>
            <div className="text-sm mt-1 text-gray-600">
              <p>{healthStatus?.database || 'Checking...'}</p>
              {healthStatus?.storage && (
                <p className="text-xs mt-1">Storage: {healthStatus.storage}</p>
              )}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-blue-100 border border-blue-300">
            <div className="flex items-center space-x-2">
              <Brain className="w-4 h-4 text-purple-600" />
              <span className="font-medium text-gray-700">AI Engine Status</span>
            </div>
            <div className="text-sm mt-1 text-gray-600">
              <p>{healthStatus?.tunnel || 'Active & Ready'}</p>
              <p className="text-xs mt-1">🤖 Resume Analysis Ready</p>
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4">
            <div className="flex items-center space-x-2 mb-2">
              <AlertCircle className="w-5 h-5 text-red-500" />
              <h3 className="text-lg font-semibold text-red-800">Dashboard Error</h3>
            </div>
            <p className="text-red-700 mb-3">{error}</p>
            <div className="flex gap-3">
              <button
                onClick={handleRefresh}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl font-medium"
              >
                Retry Connection
              </button>
              <button
                onClick={testAPIConnection}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl font-medium"
              >
                Test API
              </button>
            </div>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {dashboardStats.map((stat, index) => (
            <div
              key={stat.title}
              className="group relative bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-xl hover:border-gray-200 transition-all duration-300 overflow-hidden"
            >
              {/* Background Gradient */}
              <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-5 group-hover:opacity-10 transition-opacity duration-300`}></div>
              
              {/* Content */}
              <div className="relative">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-bold text-gray-900">{stat.value}</span>
                      <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                        stat.trend === 'up' ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'
                      }`}>
                        <TrendingUp className={`w-3 h-3 ${stat.trend === 'down' ? 'rotate-180' : ''}`} />
                        {stat.change}
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{stat.subtitle}</p>
                  </div>
                  
                  <div className={`p-3 bg-gradient-to-br ${stat.gradient} rounded-xl shadow-lg`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                
                {/* Mini Chart Placeholder */}
                <div className="flex items-end gap-1 h-8">
                  {[...Array(12)].map((_, i) => (
                    <div
                      key={i}
                      className={`flex-1 bg-gradient-to-t ${stat.gradient} opacity-20 rounded-sm`}
                      style={{ height: `${Math.random() * 100}%` }}
                    ></div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          
          {/* Recent Applications */}
          <div className="xl:col-span-2 bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-lg">
                    <Users className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">Recent Applications</h3>
                    <p className="text-sm text-gray-500">
                      Latest candidate submissions ({filteredApplications.length} 
                      {searchTerm && ` filtered from ${recentApplications.length}`})
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <Filter className="w-4 h-4 text-gray-500" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <MoreVertical className="w-4 h-4 text-gray-500" />
                  </button>
                </div>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              {filteredApplications.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h4 className="text-lg font-semibold text-gray-600 mb-2">
                    {searchTerm ? 'No matching applications' : 'No applications yet'}
                  </h4>
                  <p className="text-gray-500">
                    {searchTerm 
                      ? 'Try adjusting your search terms.' 
                      : 'Applications will appear here when candidates apply.'}
                  </p>
                  {error && (
                    <button
                      onClick={handleRefresh}
                      className="mt-4 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl font-medium"
                    >
                      Try Loading Applications
                    </button>
                  )}
                </div>
              ) : (
                <>
                  {filteredApplications.slice(0, 6).map((app, index) => (
                    <div
                      key={app.id}
                      className="group flex items-center justify-between p-4 rounded-xl hover:bg-gray-50 transition-all duration-200 border border-transparent hover:border-gray-200"
                    >
                      <div className="flex items-center gap-4">
                        <div className="relative">
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center text-white font-semibold">
                            {app.candidateName.split(' ').map(n => n[0]).join('')}
                          </div>
                          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-white rounded-full border-2 border-white">
                            {getStatusIcon(app.status)}
                          </div>
                        </div>
                        
                        <div className="flex-1">
                          <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                            {app.candidateName}
                          </p>
                          <p className="text-sm text-gray-600">{app.jobTitle}</p>
                          <div className="flex items-center gap-2 text-xs text-gray-500">
                            <span>Applied {app.appliedDate}</span>
                            {app.location && (
                              <>
                                <span>•</span>
                                <span>{app.location}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(app.status)}`}>
                          {getStatusIcon(app.status)}
                          {app.status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </span>
                        <button className="opacity-0 group-hover:opacity-100 p-2 hover:bg-gray-100 rounded-lg transition-all">
                          <ArrowUpRight className="w-4 h-4 text-gray-500" />
                        </button>
                      </div>
                    </div>
                  ))}
                  
                  <button className="w-full py-3 text-center text-blue-600 hover:text-blue-700 font-medium transition-colors border-2 border-dashed border-blue-200 hover:border-blue-300 rounded-xl">
                    View All Applications ({recentApplications.length})
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            
            {/* Active Jobs */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-100">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg">
                    <Briefcase className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Active Jobs</h3>
                    <p className="text-sm text-gray-500">Open positions ({topJobs.length})</p>
                  </div>
                </div>
              </div>
              
              <div className="p-6 space-y-4">
                {topJobs.length === 0 ? (
                  <div className="text-center py-8">
                    <Briefcase className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500 text-sm">No active jobs found</p>
                    {error && (
                      <button
                        onClick={handleRefresh}
                        className="mt-3 text-blue-600 hover:text-blue-700 text-sm font-medium"
                      >
                        Try Loading Jobs
                      </button>
                    )}
                  </div>
                ) : (
                  topJobs.slice(0, 4).map((job, index) => (
                    <div
                      key={job.id}
                      className="group flex items-center justify-between p-4 rounded-xl hover:bg-gray-50 transition-all duration-200"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                          <Briefcase className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 group-hover:text-blue-600 transition-colors text-sm">
                            {job.title}
                          </p>
                          <p className="text-xs text-gray-600">{job.department}</p>
                          {job.salaryRange && (
                            <p className="text-xs text-green-600">{job.salaryRange}</p>
                          )}
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <p className="text-sm font-semibold text-gray-900">{job.applications}</p>
                        <p className="text-xs text-gray-500">applicants</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* AI-Enhanced Quick Actions */}
            <div className="bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl p-6 text-white">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                  <Brain className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-semibold">AI-Powered Actions</h3>
              </div>
              
              <div className="space-y-3">
                <button className="w-full p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-200 text-left backdrop-blur-sm">
                  <div className="flex items-center gap-3">
                    <Plus className="w-4 h-4" />
                    <span className="text-sm font-medium">Post New Job</span>
                  </div>
                </button>
                
                <button className="w-full p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-200 text-left backdrop-blur-sm">
                  <div className="flex items-center gap-3">
                    <Brain className="w-4 h-4" />
                    <span className="text-sm font-medium">AI Resume Analysis</span>
                  </div>
                </button>
                
                <button className="w-full p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-200 text-left backdrop-blur-sm">
                  <div className="flex items-center gap-3">
                    <Calendar className="w-4 h-4" />
                    <span className="text-sm font-medium">Schedule Interview</span>
                  </div>
                </button>
                
                <button className="w-full p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-200 text-left backdrop-blur-sm">
                  <div className="flex items-center gap-3">
                    <Award className="w-4 h-4" />
                    <span className="text-sm font-medium">Send Offer</span>
                  </div>
                </button>
              </div>

              <div className="mt-4 p-3 bg-white/10 rounded-xl">
                <div className="flex items-center gap-2 text-sm">
                  <Sparkles className="w-4 h-4" />
                  <span>AI insights available for all actions</span>
                </div>
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-gradient-to-r from-green-500 to-green-600 rounded-lg">
                  <Activity className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">Performance</h3>
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Hiring Rate</span>
                  <span className="text-sm font-semibold text-green-600">
                    {stats ? Math.round((stats.total_hired / Math.max(stats.total_applications, 1)) * 100) : 0}%
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Avg. Time to Hire</span>
                  <span className="text-sm font-semibold text-blue-600">14 days</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">AI Accuracy</span>
                  <span className="text-sm font-semibold text-purple-600">94.2%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">API Status</span>
                  <span className={`text-sm font-semibold ${error ? 'text-red-600' : 'text-green-600'}`}>
                    {error ? 'Disconnected' : 'Connected'}
                  </span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default EnhancedDashboard;