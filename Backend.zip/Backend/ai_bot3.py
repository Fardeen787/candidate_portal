#!/usr/bin/env python3
"""
ai_bot.py - AI Bot Logic, Database Management, and AutoGen Agents
Enhanced version with Update and Terminate ticket functionality
"""

import re
import json
from datetime import datetime, timedelta
import hashlib
from typing import Dict, List, Tuple, Optional, Any
import autogen
from autogen import AssistantAgent
import logging
import mysql.connector
from mysql.connector import Error
from contextlib import contextmanager
import secrets
import uuid

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ============================================================================
# CONFIGURATION
# ============================================================================

class Config:
    # Groq API Configuration
    GROQ_API_KEY = "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"
    GROQ_MODEL = "deepseek-r1-distill-llama-70b"  # Stable model
    GROQ_API_BASE = "https://api.groq.com/openai/v1"
    
    # MySQL Configuration
    MYSQL_HOST = "localhost"
    MYSQL_USER = "root"
    MYSQL_PASSWORD = "root"
    MYSQL_DATABASE = "hiring_bot_chat"
    
    # Debug Mode - SET TO FALSE IN PRODUCTION!
    DEBUG_MODE = True  # Allows instant ticket approval in chat
    
    # Required hiring details
    REQUIRED_HIRING_DETAILS = [
        "job_title", "location", "experience_required", "salary_range",
        "job_description", "required_skills", "employment_type", "deadline"
    ]

# AutoGen LLM Configuration
llm_config = {
    "config_list": [{
        "model": Config.GROQ_MODEL,
        "api_key": Config.GROQ_API_KEY,
        "base_url": Config.GROQ_API_BASE,
        "api_type": "openai",
    }],
    "temperature": 0.1,
    "seed": 42,
    "cache_seed": None,
    "timeout": 120,
    "max_tokens": 1000,  # Increased for better responses
}

# ============================================================================
# DATABASE MANAGER
# ============================================================================

class DatabaseManager:
    """Manages MySQL database connections and operations"""
    
    def __init__(self):
        self.config = {
            'host': Config.MYSQL_HOST,
            'user': Config.MYSQL_USER,
            'password': Config.MYSQL_PASSWORD,
            'database': Config.MYSQL_DATABASE
        }
        self.setup_database()
    
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = None
        try:
            conn = mysql.connector.connect(**self.config)
            yield conn
        except Error as e:
            logger.error(f"Database error: {e}")
            if conn:
                conn.rollback()
            raise
        finally:
            if conn and conn.is_connected():
                conn.close()
    
    def setup_database(self):
        """Create database and tables if they don't exist"""
        config_without_db = self.config.copy()
        db_name = config_without_db.pop('database')
        
        try:
            conn = mysql.connector.connect(**config_without_db)
            cursor = conn.cursor()
            
            # Create database
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
            cursor.execute(f"USE {db_name}")
            
            # Create tables
            self._create_tables(cursor)
            
            conn.commit()
            logger.info("Database setup completed successfully")
            
        except Error as e:
            logger.error(f"Error setting up database: {e}")
            raise
        finally:
            if conn and conn.is_connected():
                cursor.close()
                conn.close()
    
    def _create_tables(self, cursor):
        """Create all required tables"""
        
        # Chat sessions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS chat_sessions (
                session_id VARCHAR(36) PRIMARY KEY,
                user_id VARCHAR(255),
                started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_activity DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                status VARCHAR(50) DEFAULT 'active',
                INDEX idx_user_id (user_id),
                INDEX idx_last_activity (last_activity)
            )
        """)
        
        # Chat messages table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS chat_messages (
                message_id INT AUTO_INCREMENT PRIMARY KEY,
                session_id VARCHAR(36) NOT NULL,
                sender_type ENUM('user', 'assistant', 'system') NOT NULL,
                message_content TEXT NOT NULL,
                message_metadata JSON,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (session_id) REFERENCES chat_sessions(session_id) ON DELETE CASCADE,
                INDEX idx_session_messages (session_id, timestamp)
            )
        """)
        
        # Tickets table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                ticket_id VARCHAR(10) PRIMARY KEY,
                session_id VARCHAR(36),
                user_id VARCHAR(255),
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                status VARCHAR(50) DEFAULT 'new',
                approval_status VARCHAR(50) DEFAULT 'pending',
                approved BOOLEAN DEFAULT FALSE,
                approved_at DATETIME,
                terminated_at DATETIME,
                termination_reason TEXT,
                FOREIGN KEY (session_id) REFERENCES chat_sessions(session_id),
                INDEX idx_user_tickets (user_id),
                INDEX idx_status (status),
                INDEX idx_approval_status (approval_status)
            )
        """)
        
        # Ticket details table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ticket_details (
                id INT AUTO_INCREMENT PRIMARY KEY,
                ticket_id VARCHAR(10) NOT NULL,
                field_name VARCHAR(100) NOT NULL,
                field_value TEXT,
                is_initial BOOLEAN DEFAULT TRUE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE,
                INDEX idx_ticket_field (ticket_id, field_name)
            )
        """)
        
        # Conversation context table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversation_context (
                context_id INT AUTO_INCREMENT PRIMARY KEY,
                session_id VARCHAR(36) NOT NULL,
                context_type VARCHAR(50) NOT NULL,
                context_data JSON,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (session_id) REFERENCES chat_sessions(session_id) ON DELETE CASCADE,
                INDEX idx_session_context (session_id)
            )
        """)
        
        # Add ticket history table for tracking updates
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ticket_history (
                history_id INT AUTO_INCREMENT PRIMARY KEY,
                ticket_id VARCHAR(10) NOT NULL,
                field_name VARCHAR(100) NOT NULL,
                old_value TEXT,
                new_value TEXT,
                changed_by VARCHAR(255),
                changed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                change_type ENUM('create', 'update', 'terminate') DEFAULT 'update',
                FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE,
                INDEX idx_ticket_history (ticket_id, changed_at)
            )
        """)

# ============================================================================
# SESSION MANAGER
# ============================================================================

class ChatSessionManager:
    """Manages chat sessions"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
    
    def create_session(self, user_id: Optional[str] = None) -> str:
        """Create a new chat session"""
        session_id = str(uuid.uuid4())
        
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO chat_sessions (session_id, user_id)
                VALUES (%s, %s)
            """, (session_id, user_id or f'user_{uuid.uuid4().hex[:8]}'))
            conn.commit()
        
        return session_id
    
    def get_session(self, session_id: str) -> Optional[Dict]:
        """Get session details"""
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT * FROM chat_sessions
                WHERE session_id = %s
            """, (session_id,))
            return cursor.fetchone()
    
    def save_message(self, session_id: str, sender_type: str, 
                    content: str, metadata: Optional[Dict] = None):
        """Save a chat message"""
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO chat_messages 
                (session_id, sender_type, message_content, message_metadata)
                VALUES (%s, %s, %s, %s)
            """, (session_id, sender_type, content, 
                  json.dumps(metadata) if metadata else None))
            
            # Update session last activity
            cursor.execute("""
                UPDATE chat_sessions 
                SET last_activity = NOW()
                WHERE session_id = %s
            """, (session_id,))
            
            conn.commit()
    
    def get_messages(self, session_id: str, limit: int = 50) -> List[Dict]:
        """Get chat messages for a session"""
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT message_id, sender_type, message_content, 
                       message_metadata, timestamp
                FROM chat_messages
                WHERE session_id = %s
                ORDER BY timestamp DESC
                LIMIT %s
            """, (session_id, limit))
            messages = cursor.fetchall()
            return list(reversed(messages))
    
    def save_context(self, session_id: str, context_type: str, 
                    context_data: Dict) -> None:
        """Save conversation context"""
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO conversation_context 
                (session_id, context_type, context_data)
                VALUES (%s, %s, %s)
            """, (session_id, context_type, json.dumps(context_data)))
            conn.commit()
    
    def get_latest_context(self, session_id: str, context_type: str) -> Optional[Dict]:
        """Get the latest context of a specific type"""
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT context_data 
                FROM conversation_context
                WHERE session_id = %s AND context_type = %s
                ORDER BY created_at DESC
                LIMIT 1
            """, (session_id, context_type))
            
            result = cursor.fetchone()
            if result and result['context_data']:
                return json.loads(result['context_data'])
            return None

# ============================================================================
# ENHANCED TICKET MANAGER
# ============================================================================

class ChatTicketManager:
    """Manages hiring tickets with update and terminate functionality"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
    
    def generate_ticket_id(self) -> str:
        """Generate a unique ticket ID"""
        return hashlib.md5(f"{datetime.now()}_{secrets.token_hex(4)}".encode()).hexdigest()[:10]
    
    def create_ticket(self, session_id: str, user_id: str, 
                     details: Dict[str, str]) -> Tuple[str, bool]:
        """Create a new ticket"""
        ticket_id = self.generate_ticket_id()
        
        try:
            with self.db_manager.get_connection() as conn:
                cursor = conn.cursor()
                
                # Create ticket
                cursor.execute("""
                    INSERT INTO tickets (ticket_id, session_id, user_id)
                    VALUES (%s, %s, %s)
                """, (ticket_id, session_id, user_id))
                
                # Insert details
                for field_name, field_value in details.items():
                    if field_value and field_value != "NOT_FOUND":
                        cursor.execute("""
                            INSERT INTO ticket_details (ticket_id, field_name, field_value)
                            VALUES (%s, %s, %s)
                        """, (ticket_id, field_name, field_value))
                        
                        # Add to history
                        cursor.execute("""
                            INSERT INTO ticket_history 
                            (ticket_id, field_name, old_value, new_value, changed_by, change_type)
                            VALUES (%s, %s, NULL, %s, %s, 'create')
                        """, (ticket_id, field_name, field_value, user_id))
                
                conn.commit()
            
            return ticket_id, True
            
        except Exception as e:
            logger.error(f"Error creating ticket: {e}")
            return None, False
    
    def update_ticket(self, ticket_id: str, user_id: str, 
                     updates: Dict[str, str]) -> Tuple[bool, str]:
        """Update ticket details"""
        try:
            with self.db_manager.get_connection() as conn:
                cursor = conn.cursor()
                
                # Check if ticket exists and belongs to user
                cursor.execute("""
                    SELECT user_id, status FROM tickets WHERE ticket_id = %s
                """, (ticket_id,))
                result = cursor.fetchone()
                
                if not result:
                    return False, "Ticket not found"
                
                if result[0] != user_id:
                    return False, "You don't have permission to update this ticket"
                
                if result[1] == 'terminated':
                    return False, "Cannot update a terminated ticket"
                
                # Update each field
                updated_fields = []
                for field_name, new_value in updates.items():
                    if field_name in Config.REQUIRED_HIRING_DETAILS and new_value:
                        # Get current value
                        cursor.execute("""
                            SELECT field_value FROM ticket_details
                            WHERE ticket_id = %s AND field_name = %s
                        """, (ticket_id, field_name))
                        
                        old_value_result = cursor.fetchone()
                        old_value = old_value_result[0] if old_value_result else None
                        
                        if old_value != new_value:
                            # Update or insert the field
                            cursor.execute("""
                                INSERT INTO ticket_details (ticket_id, field_name, field_value, is_initial)
                                VALUES (%s, %s, %s, FALSE)
                                ON DUPLICATE KEY UPDATE 
                                    field_value = VALUES(field_value),
                                    is_initial = FALSE
                            """, (ticket_id, field_name, new_value))
                            
                            # Add to history
                            cursor.execute("""
                                INSERT INTO ticket_history 
                                (ticket_id, field_name, old_value, new_value, changed_by)
                                VALUES (%s, %s, %s, %s, %s)
                            """, (ticket_id, field_name, old_value, new_value, user_id))
                            
                            updated_fields.append(field_name)
                
                # Update ticket timestamp
                cursor.execute("""
                    UPDATE tickets 
                    SET last_updated = NOW()
                    WHERE ticket_id = %s
                """, (ticket_id,))
                
                conn.commit()
                
                if updated_fields:
                    return True, f"Updated fields: {', '.join(updated_fields)}"
                else:
                    return True, "No changes were made"
                    
        except Exception as e:
            logger.error(f"Error updating ticket: {e}")
            return False, f"Error updating ticket: {str(e)}"
    
    def get_user_tickets(self, user_id: str) -> List[Dict]:
        """Get all tickets for a user"""
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT t.*, td.field_value as job_title
                FROM tickets t
                LEFT JOIN ticket_details td ON t.ticket_id = td.ticket_id 
                    AND td.field_name = 'job_title'
                WHERE t.user_id = %s
                ORDER BY t.created_at DESC
            """, (user_id,))
            return cursor.fetchall()
    
    def get_ticket_details(self, ticket_id: str) -> Optional[Dict]:
        """Get details of a specific ticket"""
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            
            # Get ticket info
            cursor.execute("""
                SELECT * FROM tickets WHERE ticket_id = %s
            """, (ticket_id,))
            ticket = cursor.fetchone()
            
            if not ticket:
                return None
            
            # Get ticket details
            cursor.execute("""
                SELECT field_name, field_value FROM ticket_details
                WHERE ticket_id = %s
            """, (ticket_id,))
            
            details = {}
            for row in cursor.fetchall():
                details[row['field_name']] = row['field_value']
            
            ticket['details'] = details
            return ticket
    
    def get_ticket_history(self, ticket_id: str) -> List[Dict]:
        """Get the history of changes for a ticket"""
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT * FROM ticket_history
                WHERE ticket_id = %s
                ORDER BY changed_at DESC
            """, (ticket_id,))
            return cursor.fetchall()
    
    def terminate_ticket(self, ticket_id: str, user_id: str, 
                        reason: str = "User requested termination") -> Tuple[bool, str]:
        """Terminate a ticket with enhanced validation"""
        try:
            with self.db_manager.get_connection() as conn:
                cursor = conn.cursor()
                
                # Check if ticket exists and belongs to user
                cursor.execute("""
                    SELECT user_id, status FROM tickets WHERE ticket_id = %s
                """, (ticket_id,))
                result = cursor.fetchone()
                
                if not result:
                    return False, "Ticket not found"
                
                if result[0] != user_id:
                    return False, "You don't have permission to terminate this ticket"
                
                if result[1] == 'terminated':
                    return False, "Ticket is already terminated"
                
                # Terminate the ticket
                cursor.execute("""
                    UPDATE tickets 
                    SET status = 'terminated',
                        terminated_at = NOW(),
                        termination_reason = %s
                    WHERE ticket_id = %s
                """, (reason, ticket_id))
                
                # Add to history
                cursor.execute("""
                    INSERT INTO ticket_history 
                    (ticket_id, field_name, old_value, new_value, changed_by, change_type)
                    VALUES (%s, 'status', %s, 'terminated', %s, 'terminate')
                """, (ticket_id, result[1], user_id))
                
                conn.commit()
                return True, "Ticket terminated successfully"
                
        except Exception as e:
            logger.error(f"Error terminating ticket: {e}")
            return False, f"Error terminating ticket: {str(e)}"

# ============================================================================
# AI AGENTS - UPDATED WITH UPDATE INTENT
# ============================================================================

class ChatClassifierAgent(AssistantAgent):
    """Agent for classifying chat messages"""
    
    def __init__(self):
        system_message = """You are a chat message classifier. Analyze the user's message and return a JSON object with the classification.

Return JSON in this exact format:
{
    "intent": "hiring|termination|question|greeting|status_check|help|approval|update",
    "is_hiring_related": true/false,
    "has_complete_info": true/false,
    "ticket_id": "extracted_id_or_null",
    "confidence": 0.0-1.0
}

Intent descriptions:
- hiring: User wants to post a new job OR is providing job details in response to questions
- termination: User wants to cancel/close/terminate a job posting
- question: User has a general question about the system
- greeting: Simple greeting, hello, hi, etc.
- status_check: User wants to check status of their tickets/jobs
- help: User explicitly asks for help or guidance
- approval: User wants to approve a ticket (e.g., "approve ticket abc123def4")
- update: User wants to update/modify an existing ticket (e.g., "update ticket abc123def4", "change salary for abc123def4")

IMPORTANT: If the conversation is already about posting a job (check context), and user provides any information like:
- Job titles (Software Engineer, Python Developer, etc.)
- Locations (Pune, Remote, etc.)
- Numbers that could be experience or salary
- Skills or requirements
- Any job-related details
Then classify as "hiring" intent, even if they don't explicitly say "I want to post a job"

For ticket_id: Look for 10-character alphanumeric IDs (e.g., "abc123def4", "c8a5325ded")
- Check after words like "approve", "ticket", "terminate", "update", "modify", "change", etc.
- The ID should be exactly 10 characters, lowercase alphanumeric

If user says something like "update ticket c8a5325ded" or "change salary for c8a5325ded", classify as "update" intent and extract the ticket_id.

IMPORTANT: Return ONLY the JSON object, no other text."""
        
        super().__init__(
            name="ChatClassifier",
            system_message=system_message,
            llm_config=llm_config,
            human_input_mode="NEVER"
        )

class ChatResponseAgent(AssistantAgent):
    """Agent for generating chat responses"""
    
    def __init__(self):
        system_message = """You are a friendly hiring assistant chatbot. Generate helpful, conversational responses.

Guidelines:
- Be warm and professional
- Use clear, simple language
- Guide users step by step
- Use emojis sparingly (👋 ✅ 🎉 📝 etc.)
- Ask for one piece of information at a time
- Confirm actions clearly
- Keep responses concise

CRITICAL: When collecting job details:
- If NO information has been collected yet (all fields are empty/NOT_FOUND), start fresh
- Don't mention having information you don't actually have
- Be accurate about what has been collected vs what's still needed

When asking for job details, be specific:
- For job title: "What position are you looking to fill?"
- For location: "Where will this position be based?"
- For experience: "How many years of experience are you looking for?"
- For salary: "What's the salary range for this position?"
- For job description: "Can you provide a brief description of the role and responsibilities?"
- For skills: "What key skills should candidates have?"
- For type: "Is this Full-time, Part-time, or Contract?"
- For deadline: "When is the application deadline? (Please provide a date in the future, e.g., DD-MM-YYYY)"

If user just says "I want to post a job" with no other details:
Say something like: "Great! I'd be happy to help you post a job. Let's start by getting some details. What position are you looking to fill?"

If user provides an invalid deadline (past date), politely ask them to provide a future date.

Always maintain a helpful, encouraging tone."""
        
        super().__init__(
            name="ChatResponder",
            system_message=system_message,
            llm_config=llm_config,
            human_input_mode="NEVER"
        )

class HiringDetailsExtractorAgent(AssistantAgent):
    """Agent for extracting hiring details - IMPROVED VERSION"""
    
    def __init__(self):
        system_message = """You are a hiring details extractor. Analyze the conversation and extract job posting details.

Return ONLY a JSON object with these fields:
{
    "job_title": "position name or NOT_FOUND",
    "location": "city/location or NOT_FOUND",
    "experience_required": "years of experience or NOT_FOUND",
    "salary_range": "salary information or NOT_FOUND",
    "job_description": "description or NOT_FOUND",
    "required_skills": "skills list or NOT_FOUND",
    "employment_type": "Full-time/Part-time/Contract or NOT_FOUND",
    "deadline": "application deadline or NOT_FOUND"
}

CRITICAL INSTRUCTIONS:
1. ONLY extract information that was EXPLICITLY stated by the user
2. If user only said "I want to post a job" with NO other details, ALL fields must be "NOT_FOUND"
3. Do NOT assume, infer, or hallucinate any values
4. Look at the CONTEXT of questions and answers:
   - If Assistant asks "How many years of experience..." and User says "2", then experience_required = "2"
   - If Assistant asks "What's the salary range..." and User says "20", then salary_range = "20"
   - If Assistant asks "Where will this position be based?" and User says "pune", then location = "pune"
   - If Assistant asks about job description and User says "python" or "working on ai", that's the job_description
   - If Assistant asks about skills and User says "python", that's required_skills = "python"
5. Look for actual values in user messages:
   * "I want to post a job" alone = ALL fields are "NOT_FOUND"
   * "I want to hire a Python developer" = job_title: "Python developer", rest are "NOT_FOUND"
   * "Software Engineer" (in response to job title question) = job_title: "Software Engineer"
   * "2" (in response to experience question) = experience_required: "2"
   * "python" (in response to job description question) = job_description: "python"
   * "python" (in response to skills question) = required_skills: "python"
6. Be extremely conservative - when in doubt, use "NOT_FOUND"
7. Return ONLY valid JSON, no other text

CONTEXT MATCHING EXAMPLES:
- Assistant: "What position are you looking to fill?" → User: "software" → job_title: "software"
- Assistant: "How many years of experience..." → User: "2" → experience_required: "2"
- Assistant: "Where will this position be based?" → User: "pune" → location: "pune"
- Assistant: "What's the salary range..." → User: "20" → salary_range: "20"
- Assistant: "Can you provide a brief description..." → User: "python" → job_description: "python"
- Assistant: "What key skills..." → User: "python" → required_skills: "python"
- Assistant: "Is this Full-time..." → User: "full" → employment_type: "full"
"""
        
        super().__init__(
            name="DetailsExtractor",
            system_message=system_message,
            llm_config=llm_config,
            human_input_mode="NEVER"
        )

class UpdateDetailsExtractorAgent(AssistantAgent):
    """Agent for extracting update details from conversation"""
    
    def __init__(self):
        system_message = """You are an update details extractor. Analyze the conversation and extract what fields the user wants to update.

Return ONLY a JSON object with fields they want to update:
{
    "job_title": "new value or null",
    "location": "new value or null",
    "experience_required": "new value or null",
    "salary_range": "new value or null",
    "job_description": "new value or null",
    "required_skills": "new value or null",
    "employment_type": "new value or null",
    "deadline": "new value or null"
}

IMPORTANT:
1. Only include fields that the user explicitly wants to update
2. Set field value to null if not mentioned
3. Extract actual new values from the conversation
4. If user says "change salary to 30 lakhs", then salary_range = "30 lakhs"
5. If user says "update location to Mumbai", then location = "Mumbai"
6. Return ONLY valid JSON, no other text"""
        
        super().__init__(
            name="UpdateExtractor",
            system_message=system_message,
            llm_config=llm_config,
            human_input_mode="NEVER"
        )

# ============================================================================
# MAIN CHAT BOT HANDLER - ENHANCED WITH UPDATE
# ============================================================================

class ChatBotHandler:
    """Main chat bot handler that coordinates everything"""
    
    def __init__(self):
        self.db_manager = DatabaseManager()
        self.session_manager = ChatSessionManager(self.db_manager)
        self.ticket_manager = ChatTicketManager(self.db_manager)
        
        # Initialize AI agents
        self.classifier = ChatClassifierAgent()
        self.responder = ChatResponseAgent()
        self.extractor = HiringDetailsExtractorAgent()
        self.update_extractor = UpdateDetailsExtractorAgent()  # New agent for updates
        
        # Log debug mode status
        if Config.DEBUG_MODE:
            logger.warning("DEBUG MODE IS ENABLED - Instant ticket approval is active!")
    
    def start_session(self, user_id: Optional[str] = None) -> Dict:
        """Start a new chat session"""
        session_id = self.session_manager.create_session(user_id)
        
        welcome_message = ("Hello! 👋 I'm your hiring assistant. I can help you:\n\n"
                          "• Post new job openings\n"
                          "• Check status of your postings\n"
                          "• Update existing tickets\n"
                          "• Terminate job postings\n"
                          "• Manage your hiring needs\n\n"
                          "What would you like to do today?")
        
        self.session_manager.save_message(session_id, "assistant", welcome_message)
        
        return {
            'session_id': session_id,
            'user_id': user_id or f'user_{uuid.uuid4().hex[:8]}',
            'message': welcome_message
        }
    
    def process_message(self, session_id: str, user_id: str, 
                       message: str) -> Dict[str, Any]:
        """Process a user message and generate response"""
        
        try:
            # Save user message
            self.session_manager.save_message(session_id, "user", message)
            
            # Get conversation history
            history = self.session_manager.get_messages(session_id, limit=10)
            
            # Classify the message
            classification = self._classify_message(message, history)
            
            # Generate appropriate response
            response = self._generate_response(
                session_id, user_id, message, classification, history
            )
            
            # Save assistant response
            self.session_manager.save_message(
                session_id, "assistant", response['message'],
                metadata=response.get('metadata')
            )
            
            return response
            
        except Exception as e:
            logger.error(f"Error in process_message: {str(e)}")
            logger.error(f"Session ID: {session_id}, User ID: {user_id}, Message: {message}")
            import traceback
            traceback.print_exc()
            raise
    
    def _classify_message(self, message: str, history: List[Dict]) -> Dict:
        """Classify user message intent"""
        context = self._build_context(history)
        
        # Check if we're in an active hiring flow
        recent_messages = history[-5:] if len(history) >= 5 else history
        in_hiring_flow = False
        ticket_just_created = False
        in_update_flow = False
        
        # Check conversation state
        for msg in reversed(recent_messages):
            if msg['sender_type'] == 'assistant':
                metadata = msg.get('message_metadata')
                if metadata:
                    try:
                        metadata_dict = json.loads(metadata) if isinstance(metadata, str) else metadata
                        if metadata_dict.get('action') == 'ticket_created':
                            ticket_just_created = True
                            break
                        elif metadata_dict.get('intent') == 'update':
                            in_update_flow = True
                    except:
                        pass
        
        # Check for explicit update keywords
        message_lower = message.lower()
        if any(word in message_lower for word in ['update', 'modify', 'change', 'edit']) and \
           any(char.isdigit() or char.isalpha() for char in message_lower):
            # Likely an update intent
            classification = {
                "intent": "update",
                "is_hiring_related": True,
                "has_complete_info": False,
                "confidence": 0.9
            }
            # Try to extract ticket ID
            match = re.search(r'[a-f0-9]{10}', message_lower)
            if match:
                classification['ticket_id'] = match.group(0)
            return classification
        
        # Only consider in hiring flow if we haven't just created a ticket
        if not ticket_just_created and not in_update_flow:
            in_hiring_flow = any(
                'metadata' in msg and msg.get('metadata', {}).get('intent') == 'hiring'
                for msg in recent_messages
                if msg['sender_type'] == 'assistant'
            )
        
        prompt = f"""
        Classify this message:
        
        Current message: {message}
        
        Recent conversation context:
        {context}
        
        {"IMPORTANT: We are in an update flow. Look for field updates." if in_update_flow else ""}
        {"IMPORTANT: A ticket was just created. Unless the user explicitly says 'I want to post another job' or similar, do NOT classify as hiring intent." if ticket_just_created else ""}
        {"IMPORTANT: The user is currently in the middle of posting a job. Unless they explicitly ask for something else (like 'show my tickets'), treat responses as hiring-related information." if in_hiring_flow and not ticket_just_created else ""}
        """
        
        response = self.classifier.generate_reply(
            messages=[{"content": prompt, "role": "user"}]
        )
        
        classification = extract_json_from_text(response)
        
        if not classification:
            # Fallback classification
            classification = {
                "intent": "update" if in_update_flow else ("hiring" if (in_hiring_flow and not ticket_just_created) else "question"),
                "is_hiring_related": in_hiring_flow and not ticket_just_created,
                "has_complete_info": False,
                "confidence": 0.7
            }
        
        return classification
    
    def _generate_response(self, session_id: str, user_id: str, 
                          message: str, classification: Dict,
                          history: List[Dict]) -> Dict:
        """Generate response based on intent"""
        
        intent = classification.get('intent', 'question')
        
        # Check for explicit commands first
        message_lower = message.lower()
        
        # Check for "show ticket" intent BEFORE other intents
        if 'show' in message_lower and any(char.isdigit() or char.isalpha() for char in message_lower):
            # Check if it's "show my tickets" vs "show [ticket_id]"
            if not any(phrase in message_lower for phrase in ['show my tickets', 'my tickets', 'all tickets']):
                # Extract ticket ID
                match = re.search(r'[a-f0-9]{10}', message_lower)
                if match:
                    ticket_id = match.group(0)
                    return self._handle_show_ticket_intent(session_id, user_id, message, ticket_id)
        
        # Override intent based on keywords
        if 'approve' in message_lower and any(char.isdigit() or char.isalpha() for char in message_lower):
            intent = 'approval'
        elif any(phrase in message_lower for phrase in ['update ticket', 'modify ticket', 'change ticket', 'edit ticket']):
            intent = 'update'
        elif any(phrase in message_lower for phrase in ['show my tickets', 'my tickets', 'list tickets', 'show tickets']):
            intent = 'status_check'
        elif any(phrase in message_lower for phrase in ['terminate ticket', 'close ticket', 'cancel ticket']):
            intent = 'termination'
        elif any(phrase in message_lower for phrase in ['help', 'how to', 'what can you do']):
            intent = 'help'
        
        handlers = {
            'hiring': self._handle_hiring_intent,
            'termination': self._handle_termination_intent,
            'status_check': self._handle_status_check,
            'help': self._handle_help_request,
            'greeting': self._handle_greeting,
            'question': self._handle_general_question,
            'approval': self._handle_approval_intent,
            'update': self._handle_update_intent
        }
        
        handler = handlers.get(intent, self._handle_general_question)
        
        if intent in ['hiring', 'termination', 'question', 'approval', 'update']:
            return handler(session_id, user_id, message, classification, history)
        else:
            return handler(user_id)
    
    def _handle_show_ticket_intent(self, session_id: str, user_id: str,
                                   message: str, ticket_id: str) -> Dict:
        """Handle showing specific ticket details without update flow"""
        
        # Get ticket details
        ticket = self.ticket_manager.get_ticket_details(ticket_id)
        
        if not ticket:
            return {
                "message": f"❌ I couldn't find ticket `{ticket_id}`. Please check the ticket ID and try again.",
                "metadata": {"intent": "show_ticket", "error": "ticket_not_found"}
            }
        
        if ticket['user_id'] != user_id:
            return {
                "message": "❌ You don't have permission to view this ticket.",
                "metadata": {"intent": "show_ticket", "error": "permission_denied"}
            }
        
        # Format ticket details
        details = ticket['details']
        status_emoji = "✅" if ticket['approval_status'] == 'approved' else "⏳"
        
        # Format dates nicely
        created_date = ticket['created_at']
        updated_date = ticket['last_updated']
        
        if isinstance(created_date, str):
            created_date = datetime.fromisoformat(created_date)
        if isinstance(updated_date, str):
            updated_date = datetime.fromisoformat(updated_date)
        
        response_text = f"""📋 **Ticket Details for `{ticket_id}`**

**Status:** {status_emoji} {ticket['approval_status'].title()}
{f"**Terminated:** Yes - {ticket['termination_reason']}" if ticket['status'] == 'terminated' else ""}

**Job Information:**
• **Position:** {details.get('job_title', 'Not set')}
• **Location:** {details.get('location', 'Not set')}
• **Experience Required:** {details.get('experience_required', 'Not set')}
• **Salary Range:** {details.get('salary_range', 'Not set')}
• **Employment Type:** {details.get('employment_type', 'Not set')}
• **Application Deadline:** {details.get('deadline', 'Not set')}

**Job Description:**
{details.get('job_description', 'Not set')}

**Required Skills:**
{details.get('required_skills', 'Not set')}

**Timestamps:**
• **Created:** {created_date.strftime('%d-%m-%Y at %I:%M %p')}
• **Last Updated:** {updated_date.strftime('%d-%m-%Y at %I:%M %p')}

**Available Actions:**
• Say 'Update ticket {ticket_id}' to modify this posting
• Say 'Terminate ticket {ticket_id}' to close this posting
• Say 'Show my tickets' to see all your postings"""
        
        return {
            "message": response_text,
            "metadata": {"intent": "show_ticket", "ticket_id": ticket_id}
        }
    
    def _handle_update_intent(self, session_id: str, user_id: str,
                             message: str, classification: Dict,
                             history: List[Dict]) -> Dict:
        """Handle ticket update requests"""
        
        # Check if this is actually a "show" request
        message_lower = message.lower()
        if 'show' in message_lower and not any(word in message_lower for word in ['update', 'change', 'modify', 'edit']):
            # This is a show request, not an update request
            # Extract ticket ID
            ticket_id = classification.get('ticket_id')
            if not ticket_id:
                match = re.search(r'[a-f0-9]{10}', message_lower)
                if match:
                    ticket_id = match.group(0)
            
            if ticket_id:
                return self._handle_show_ticket_intent(session_id, user_id, message, ticket_id)
        
        # Continue with normal update flow...
        # Check if we have an update context
        update_context = self.session_manager.get_latest_context(session_id, 'update_flow')
        
        # Extract ticket ID
        ticket_id = classification.get('ticket_id')
        if not ticket_id and update_context:
            ticket_id = update_context.get('ticket_id')
        
        if not ticket_id:
            # Try regex extraction
            match = re.search(r'[a-f0-9]{10}', message.lower())
            if match:
                ticket_id = match.group(0)
        
        if not ticket_id:
            # No ticket ID - show user's tickets
            tickets = self.ticket_manager.get_user_tickets(user_id)
            active_tickets = [t for t in tickets if t['status'] != 'terminated']
            
            if active_tickets:
                ticket_list = "\n".join([
                    f"• `{t['ticket_id']}` - {t['job_title'] or 'Untitled'}"
                    for t in active_tickets
                ])
                response_text = f"""I see you want to update a job posting. Here are your active tickets:

{ticket_list}

Please tell me which ticket you'd like to update. For example: "Update ticket abc123def4" """
            else:
                response_text = "You don't have any active job postings to update. Would you like to create a new job posting instead?"
            
            return {
                "message": response_text,
                "metadata": {"intent": "update", "awaiting_ticket_id": True}
            }
        
        # Get ticket details
        ticket = self.ticket_manager.get_ticket_details(ticket_id)
        
        if not ticket:
            return {
                "message": f"❌ I couldn't find ticket `{ticket_id}`. Please check the ticket ID and try again.",
                "metadata": {"intent": "update", "error": "ticket_not_found"}
            }
        
        if ticket['user_id'] != user_id:
            return {
                "message": "❌ You don't have permission to update this ticket.",
                "metadata": {"intent": "update", "error": "permission_denied"}
            }
        
        if ticket['status'] == 'terminated':
            return {
                "message": "❌ This ticket has been terminated and cannot be updated.",
                "metadata": {"intent": "update", "error": "ticket_terminated"}
            }
        
        # Check if we're collecting update details
        if update_context and update_context.get('ticket_id') == ticket_id:
            # We're in the middle of collecting updates
            updates_so_far = update_context.get('updates', {})
            
            # Extract updates from the message
            extraction_prompt = f"""
            The user is updating ticket {ticket_id}. Extract what they want to update from their message.
            
            Current ticket details:
            {json.dumps(ticket['details'], indent=2)}
            
            User message: {message}
            
            Previous context: {json.dumps(update_context, indent=2)}
            """
            
            response = self.update_extractor.generate_reply(
                messages=[{"content": extraction_prompt, "role": "user"}]
            )
            
            new_updates = extract_json_from_text(response) or {}
            
            # Merge with existing updates
            for field, value in new_updates.items():
                if value and value != "null":
                    updates_so_far[field] = value
            
            # Special handling for salary to preserve format
            if 'salary_range' in updates_so_far:
                salary_value = updates_so_far['salary_range']
                # If it's just a number, assume lakhs per annum
                if salary_value and salary_value.replace('.', '').isdigit():
                    updates_so_far['salary_range'] = f"{salary_value} lakhs per annum"
                elif salary_value and any(c.isdigit() for c in salary_value) and \
                     'lakh' not in salary_value.lower() and 'k' not in salary_value.lower():
                    updates_so_far['salary_range'] = f"{salary_value} lakhs per annum"
            
            # Check if we have any updates
            if updates_so_far:
                # Perform the update
                success, message_text = self.ticket_manager.update_ticket(
                    ticket_id, user_id, updates_so_far
                )
                
                if success:
                    # Format the success message
                    job_title = ticket['details'].get('job_title', 'Unknown Position')
                    
                    update_summary = []
                    for field, value in updates_so_far.items():
                        field_name = field.replace('_', ' ').title()
                        update_summary.append(f"• **{field_name}:** {value}")
                    
                    response_text = f"""✅ Successfully updated ticket `{ticket_id}`!

**Job Title:** {job_title}

**Updated Fields:**
{chr(10).join(update_summary)}

The changes have been saved. Is there anything else you'd like to update or do?"""
                    
                    # Clear update context
                    self.session_manager.save_context(session_id, 'update_flow', {})
                else:
                    response_text = f"❌ Error updating ticket: {message_text}"
                
                return {
                    "message": response_text,
                    "metadata": {
                        "intent": "update",
                        "action": "updated" if success else "error",
                        "ticket_id": ticket_id
                    }
                }
            else:
                # Ask what they want to update - but show ALL details
                response_text = f"""I'm ready to update ticket `{ticket_id}`.

**Current Details:**
• **Job Title:** {ticket['details'].get('job_title', 'Not set')}
• **Location:** {ticket['details'].get('location', 'Not set')}
• **Experience:** {ticket['details'].get('experience_required', 'Not set')}
• **Salary:** {ticket['details'].get('salary_range', 'Not set')}
• **Type:** {ticket['details'].get('employment_type', 'Not set')}
• **Deadline:** {ticket['details'].get('deadline', 'Not set')}
• **Description:** {ticket['details'].get('job_description', 'Not set')}
• **Required Skills:** {ticket['details'].get('required_skills', 'Not set')}

What would you like to update? You can say things like:
- "Change the salary to 25 lakhs"
- "Update location to Mumbai"
- "Modify experience to 5 years"
- "Update job description to [new description]"
- "Change required skills to Python, Java, React"

You can update multiple fields at once."""
                
                # Save context
                self.session_manager.save_context(session_id, 'update_flow', {
                    'ticket_id': ticket_id,
                    'updates': {},
                    'timestamp': datetime.now().isoformat()
                })
                
                return {
                    "message": response_text,
                    "metadata": {
                        "intent": "update",
                        "ticket_id": ticket_id,
                        "awaiting_updates": True
                    }
                }
        else:
            # First time asking about updates - show ALL details
            response_text = f"""I found ticket `{ticket_id}` for **{ticket['details'].get('job_title', 'Unknown Position')}**.

**Current Details:**
• **Location:** {ticket['details'].get('location', 'Not set')}
• **Experience:** {ticket['details'].get('experience_required', 'Not set')}
• **Salary:** {ticket['details'].get('salary_range', 'Not set')}
• **Type:** {ticket['details'].get('employment_type', 'Not set')}
• **Deadline:** {ticket['details'].get('deadline', 'Not set')}
• **Description:** {ticket['details'].get('job_description', 'Not set')}
• **Required Skills:** {ticket['details'].get('required_skills', 'Not set')}

What would you like to update? Tell me the field and new value."""
            
            # Save context
            self.session_manager.save_context(session_id, 'update_flow', {
                'ticket_id': ticket_id,
                'updates': {},
                'timestamp': datetime.now().isoformat()
            })
            
            return {
                "message": response_text,
                "metadata": {
                    "intent": "update",
                    "ticket_id": ticket_id,
                    "showing_details": True
                }
            }
    
    def _handle_termination_intent(self, session_id: str, user_id: str,
                                  message: str, classification: Dict,
                                  history: List[Dict]) -> Dict:
        """Handle ticket termination requests - Enhanced version"""
        
        # Extract ticket ID
        ticket_id = classification.get('ticket_id')
        if not ticket_id:
            # Try regex extraction
            match = re.search(r'[a-f0-9]{10}', message.lower())
            if match:
                ticket_id = match.group(0)
        
        if ticket_id:
            # Verify ticket and terminate
            success, message_text = self.ticket_manager.terminate_ticket(
                ticket_id, user_id, "User requested termination via chat"
            )
            
            if success:
                # Get ticket details for confirmation
                ticket = self.ticket_manager.get_ticket_details(ticket_id)
                job_title = ticket['details'].get('job_title', 'Unknown Position') if ticket else 'Unknown Position'
                
                response_text = f"""✅ I've successfully terminated ticket `{ticket_id}`.

The job posting for **{job_title}** has been removed and is no longer active.

Is there anything else I can help you with?"""
            else:
                response_text = f"❌ {message_text}"
        else:
            # No ticket ID provided - show user's tickets
            tickets = self.ticket_manager.get_user_tickets(user_id)
            active_tickets = [t for t in tickets if t['status'] != 'terminated']
            
            if active_tickets:
                ticket_list = "\n".join([
                    f"• `{t['ticket_id']}` - {t['job_title'] or 'Untitled'}"
                    for t in active_tickets
                ])
                response_text = f"""I see you want to terminate a job posting. Here are your active tickets:

{ticket_list}

Please tell me which ticket ID you'd like to terminate. For example: "Terminate ticket abc123def4" """
            else:
                response_text = "You don't have any active job postings to terminate. Would you like to create a new job posting instead?"
        
        return {
            "message": response_text,
            "metadata": {
                "intent": "termination",
                "ticket_id": ticket_id,
                "success": success if ticket_id else None
            }
        }
    
    def _handle_help_request(self, user_id: str) -> Dict:
        """Handle help requests - Updated with new features"""
        response_text = """I'm here to help! Here's what I can do for you:

**📝 Post a New Job**
Just say "I want to post a job" and I'll guide you through the process step by step.

**✏️ Update a Job Posting**
Say "Update ticket [ID]" to modify any details of your existing job postings.

**📊 Check Your Postings**
Ask "Show my tickets" or "What's my status" to see all your job postings.

**👁️ View Ticket Details**
Say "Show [ticket ID]" to see complete details of a specific ticket.

**❌ Terminate a Posting**
Say "Terminate ticket [ID]" to close a job posting.

**💡 Tips:**
• I'll ask for job details one at a time to make it easy
• Each posting gets a unique ticket ID for tracking
• You can update any field of your posting anytime
• Approved postings appear on your website automatically

**Example Commands:**
• "I want to post a job"
• "Show my tickets"
• "Show adf08b1ca1"
• "Update ticket abc123def4"
• "Terminate ticket xyz789ghi0"
• "Change salary for ticket abc123def4 to 30 lakhs"

What would you like to do?"""
        
        # Add debug mode tip if enabled
        if Config.DEBUG_MODE:
            response_text += "\n\n**🔧 Debug Mode Active:**\n• You can approve tickets instantly with 'approve ticket [ID]'"
        
        return {
            "message": response_text,
            "metadata": {"intent": "help"}
        }
    
    def _handle_status_check(self, user_id: str) -> Dict:
        """Handle status check requests - Enhanced version"""
        tickets = self.ticket_manager.get_user_tickets(user_id)
        
        if not tickets:
            response_text = "You haven't posted any jobs yet. Would you like to create your first job posting?"
        else:
            active_tickets = [t for t in tickets if t['status'] != 'terminated']
            terminated_tickets = [t for t in tickets if t['status'] == 'terminated']
            
            response_parts = ["Here's a summary of your job postings:\n"]
            
            if active_tickets:
                response_parts.append("**📋 Active Postings:**")
                for ticket in active_tickets:
                    status_emoji = "✅" if ticket['approval_status'] == 'approved' else "⏳"
                    response_parts.append(
                        f"• {status_emoji} `{ticket['ticket_id']}` - {ticket['job_title'] or 'Untitled'} "
                        f"(Status: {ticket['approval_status'].title()})"
                    )
                    
                    # Add last updated info
                    if ticket.get('last_updated'):
                        last_updated = ticket['last_updated']
                        if isinstance(last_updated, str):
                            last_updated = datetime.fromisoformat(last_updated)
                        days_ago = (datetime.now() - last_updated).days
                        if days_ago == 0:
                            response_parts.append(f"  Last updated: Today")
                        elif days_ago == 1:
                            response_parts.append(f"  Last updated: Yesterday")
                        else:
                            response_parts.append(f"  Last updated: {days_ago} days ago")
            
            if terminated_tickets:
                response_parts.append("\n**🗑️ Recently Terminated:**")
                for ticket in terminated_tickets[:3]:
                    response_parts.append(
                        f"• `{ticket['ticket_id']}` - {ticket['job_title'] or 'Untitled'}"
                    )
            
            response_parts.append("\n**Available Actions:**")
            response_parts.append("• Say 'Show [ticket ID]' to view full details")
            response_parts.append("• Say 'Update ticket [ID]' to modify a posting")
            response_parts.append("• Say 'Terminate ticket [ID]' to close a posting")
            response_parts.append("• Say 'I want to post a job' to create a new posting")
            
            response_text = "\n".join(response_parts)
        
        return {
            "message": response_text,
            "metadata": {"intent": "status_check"}
        }
    
    def _handle_approval_intent(self, session_id: str, user_id: str,
                               message: str, classification: Dict,
                               history: List[Dict]) -> Dict:
        """Handle ticket approval requests (DEBUG MODE ONLY)"""
        
        # Check if debug mode is enabled
        if not Config.DEBUG_MODE:
            return {
                "message": ("I understand you want to approve a ticket. As a chatbot, I don't have the ability to approve tickets directly.\n\n"
                           "**Ticket Approval Process:**\n"
                           "• Tickets are reviewed and approved by HR administrators\n"
                           "• They will review your posting through the admin panel\n"
                           "• Once approved, your job will be visible on the website\n"
                           "• You'll receive notification when the status changes\n\n"
                           "The approval process typically takes 1-2 business days. Your ticket is currently in the queue for review.\n\n"
                           "Is there anything else I can help you with?"),
                "metadata": {"intent": "approval", "debug_mode": False}
            }
        
        # Extract ticket ID from classification or message
        ticket_id = classification.get('ticket_id')
        
        # If not in classification, try regex extraction
        if not ticket_id:
            import re
            match = re.search(r'[a-f0-9]{10}', message.lower())
            if match:
                ticket_id = match.group(0)
        
        # No ticket ID found
        if not ticket_id:
            return {
                "message": ("Please provide a ticket ID to approve. "
                           "For example: 'approve ticket c8a5325ded'"),
                "metadata": {"intent": "approval", "error": "no_ticket_id"}
            }
        
        # Check if ticket exists
        ticket = self.ticket_manager.get_ticket_details(ticket_id)
        
        if not ticket:
            return {
                "message": f"❌ Ticket `{ticket_id}` not found. Please check the ticket ID and try again.",
                "metadata": {"intent": "approval", "error": "ticket_not_found"}
            }
        
        # Check if already approved
        if ticket['approval_status'] == 'approved':
            return {
                "message": f"ℹ️ Ticket `{ticket_id}` is already approved!",
                "metadata": {"intent": "approval", "already_approved": True}
            }
        
        # Perform the approval
        try:
            with self.db_manager.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE tickets 
                    SET approval_status = 'approved', 
                        approved = TRUE,
                        approved_at = NOW()
                    WHERE ticket_id = %s
                """, (ticket_id,))
                conn.commit()
            
            # Get job title for confirmation
            job_title = ticket['details'].get('job_title', 'Unknown Position')
            
            return {
                "message": f"""✅ **Ticket Approved! (Debug Mode)**

**Ticket ID:** `{ticket_id}`
**Job Title:** {job_title}
**Status:** Approved ✓

The job posting is now live and candidates can start applying!

⚠️ **Note:** This approval was done in DEBUG mode. 
In production, only HR administrators can approve tickets.

What would you like to do next?
• Post another job
• Check your tickets
• Update this ticket
• Get help""",
                "metadata": {
                    "intent": "approval",
                    "action": "approved",
                    "ticket_id": ticket_id,
                    "debug_mode": True
                }
            }
            
        except Exception as e:
            logger.error(f"Error approving ticket: {e}")
            return {
                "message": f"❌ Error approving ticket: {str(e)}",
                "metadata": {"intent": "approval", "error": str(e)}
            }
    
    def _handle_hiring_intent(self, session_id: str, user_id: str,
                             message: str, classification: Dict,
                             history: List[Dict]) -> Dict:
        """Handle job posting intent - FIXED VERSION WITH CONTEXT CLEARING"""
        
        # Check if we have ongoing hiring context
        hiring_context = self.session_manager.get_latest_context(session_id, 'hiring_flow')
        
        # CRITICAL: Check if the last message was a ticket creation success
        # If so, we should clear the context to avoid creating duplicate tickets
        if history and len(history) >= 2:
            last_assistant_msg = None
            for msg in reversed(history):
                if msg['sender_type'] == 'assistant':
                    last_assistant_msg = msg
                    break
            
            if last_assistant_msg:
                # Check if the last assistant message was a ticket creation
                metadata = last_assistant_msg.get('message_metadata')
                if metadata:
                    try:
                        metadata_dict = json.loads(metadata) if isinstance(metadata, str) else metadata
                        if metadata_dict.get('action') == 'ticket_created':
                            # Clear the hiring context to start fresh
                            hiring_context = None
                            self.session_manager.save_context(session_id, 'hiring_flow', {
                                'collected_fields': {},
                                'timestamp': datetime.now().isoformat(),
                                'cleared': True
                            })
                    except:
                        pass
        
        # For simple greetings or questions after ticket creation, redirect
        message_lower = message.lower().strip()
        if hiring_context and hiring_context.get('cleared'):
            if message_lower in ['hello', 'hi', 'hey', 'hellloo', 'hellooo']:
                return self._handle_greeting(user_id)
            elif 'approve' in message_lower or 'how' in message_lower:
                return self._handle_general_question(session_id, user_id, message, classification, history)
        
        # Build full conversation context
        full_context = self._build_hiring_context(history, message)
        
        # Extract details from conversation
        extraction_prompt = f"""
        Extract all job posting details from this conversation:
        
        {full_context}
        
        IMPORTANT: 
        - Only extract information that was ACTUALLY mentioned by the user
        - Do NOT assume or infer any values
        - Use "NOT_FOUND" for any field that hasn't been explicitly provided
        - If user just said "I want to post a job" without any details, ALL fields should be "NOT_FOUND"
        - If the conversation shows a ticket was already created, ALL fields should be "NOT_FOUND" unless the user is explicitly providing new job details
        
        CONTEXT AWARENESS:
        - If the assistant asked "How many years of experience..." and the user replied with just a number like "2", 
          that number is the experience_required
        - If the assistant asked about salary and user gives numbers, those are for salary_range
        - Pay attention to what question was asked before the user's response
        
        Look for:
        - If user said "python developer" or "Software Engineer", that's the job_title
        - If user said "Pune" or "Remote", that's the location  
        - If user said "2" after being asked about experience, that's "2 years"
        - If user said "10 to 15" after being asked about salary, that's the salary_range
        - Skills, job descriptions, etc. only if explicitly mentioned
        """
        
        extraction_response = self.extractor.generate_reply(
            messages=[{"content": extraction_prompt, "role": "user"}]
        )
        
        # Add debugging
        logger.info(f"Raw extraction response: {extraction_response}")
        
        details = extract_json_from_text(extraction_response) or {}
        
        # Log extraction for debugging
        logger.info(f"Extracted details: {details}")
        
        # Clean up extraction - ensure we don't have false positives
        cleaned_details = {}
        for key, value in details.items():
            if value and value != "NOT_FOUND" and len(str(value)) > 0:
                cleaned_details[key] = value
            else:
                cleaned_details[key] = "NOT_FOUND"
        
        # Special handling for experience - if it's just a number, format it
        if 'experience_required' in cleaned_details and cleaned_details['experience_required'] != "NOT_FOUND":
            exp_value = str(cleaned_details['experience_required']).strip()
            if exp_value.isdigit():
                cleaned_details['experience_required'] = f"{exp_value} years"
            elif not any(word in exp_value.lower() for word in ['year', 'yr', 'month', 'fresh']):
                # If it's a number but doesn't have year/month, assume years
                cleaned_details['experience_required'] = f"{exp_value} years"
        
        # CRITICAL: Only merge with existing context if we're actively collecting details
        # and haven't completed a ticket recently
        if hiring_context and hiring_context.get('collected_fields') and not hiring_context.get('cleared'):
            existing_details = hiring_context['collected_fields']
            # Check if all required fields were already collected
            all_collected = all(
                existing_details.get(field) and existing_details.get(field) != "NOT_FOUND"
                for field in Config.REQUIRED_HIRING_DETAILS
            )
            
            if all_collected:
                # All fields were already collected, this might be a new request
                # Only merge if the user is explicitly providing new job details
                if not any(cleaned_details.get(field) != "NOT_FOUND" for field in Config.REQUIRED_HIRING_DETAILS):
                    # No new job details provided, treat as a different intent
                    return self._handle_general_question(session_id, user_id, message, classification, history)
            else:
                # Still collecting details, merge with existing
                for key, value in existing_details.items():
                    if key not in cleaned_details or cleaned_details[key] == "NOT_FOUND":
                        cleaned_details[key] = value
        
        # Normalize some common issues
        if 'salary_range' in cleaned_details and cleaned_details['salary_range'] != "NOT_FOUND":
            sal_value = cleaned_details['salary_range']
            if 'lakh' not in sal_value.lower() and 'k' not in sal_value.lower() and any(c.isdigit() for c in sal_value):
                # Assume lakhs for Indian context if just numbers given
                cleaned_details['salary_range'] = f"{sal_value} lakhs per annum"
        
        # Log what we've collected so far for debugging
        logger.info(f"Collected details so far: {cleaned_details}")
        
        # Save current hiring context (not cleared)
        self.session_manager.save_context(session_id, 'hiring_flow', {
            'collected_fields': cleaned_details,
            'timestamp': datetime.now().isoformat(),
            'cleared': False
        })
        
        # Check for missing required fields
        missing_fields = []
        for field in Config.REQUIRED_HIRING_DETAILS:
            if field not in cleaned_details or cleaned_details.get(field) == "NOT_FOUND":
                missing_fields.append(field)
        
        # Special handling for deadline validation BEFORE asking for other fields
        if 'deadline' in cleaned_details and cleaned_details['deadline'] != "NOT_FOUND" and cleaned_details['deadline']:
            # User provided a deadline, let's validate it
            is_valid, message, parsed_date = parse_and_validate_deadline(cleaned_details['deadline'])
            
            if not is_valid:
                # Invalid deadline - need to ask for it again
                logger.info(f"Invalid deadline provided: {cleaned_details['deadline']} - Error: {message}")
                
                # Clear the invalid deadline
                cleaned_details['deadline'] = "NOT_FOUND"
                
                # Make sure deadline is in missing fields
                if 'deadline' not in missing_fields:
                    missing_fields.append('deadline')
                
                # Save updated context
                self.session_manager.save_context(session_id, 'hiring_flow', {
                    'collected_fields': cleaned_details,
                    'timestamp': datetime.now().isoformat(),
                    'cleared': False
                })
                
                # Create response asking for valid deadline
                prompt = f"""
                The user provided an invalid deadline for the job posting.
                Error: {message}
                
                Ask them to provide a valid future date for the application deadline.
                Be friendly and helpful. Give an example of the correct format.
                Today's date is {datetime.now().strftime('%d-%m-%Y')}.
                """
                
                response_text = self.responder.generate_reply(
                    messages=[{"content": prompt, "role": "user"}]
                )
                
                return {
                    "message": response_text,
                    "metadata": {
                        "intent": "hiring",
                        "missing_fields": missing_fields,
                        "collected_fields": cleaned_details,
                        "deadline_error": message
                    }
                }
            else:
                # Valid deadline - update with formatted version
                cleaned_details['deadline'] = message  # message contains the formatted date
                
                # Save the updated context with the valid deadline
                self.session_manager.save_context(session_id, 'hiring_flow', {
                    'collected_fields': cleaned_details,
                    'timestamp': datetime.now().isoformat(),
                    'cleared': False
                })
                
                # Remove deadline from missing fields if it was there
                if 'deadline' in missing_fields:
                    missing_fields.remove('deadline')
                
                # Log for debugging
                logger.info(f"Valid deadline saved: {message}")
                logger.info(f"Updated details after deadline validation: {cleaned_details}")
                logger.info(f"Remaining missing fields: {missing_fields}")
        
        if missing_fields:
            # Ask for the next missing field
            field_to_ask = missing_fields[0]
            field_friendly_name = field_to_ask.replace('_', ' ').title()
            
            # Build a list of what we have so far (only real values)
            collected_info = {k: v for k, v in cleaned_details.items() 
                             if v != "NOT_FOUND" and v is not None}
            
            # Only ask for next field if we still have missing fields
            if missing_fields:
                # Generate conversational prompt for missing field
                if collected_info:
                    # Format collected info nicely
                    collected_summary = []
                    if 'job_title' in collected_info:
                        collected_summary.append(f"Position: {collected_info['job_title']}")
                    if 'location' in collected_info:
                        collected_summary.append(f"Location: {collected_info['location']}")
                    if 'experience_required' in collected_info:
                        collected_summary.append(f"Experience: {collected_info['experience_required']}")
                    
                    prompt = f"""
                    The user is posting a job. We have collected:
                    {', '.join(collected_summary)}
                    
                    Now ask for the {field_friendly_name}.
                    Be friendly, conversational, and acknowledge their progress.
                    Don't repeat information we already have.
                    Keep the response brief and natural.
                    {"For the deadline, mention they should provide a future date and give the format (DD-MM-YYYY)." if field_to_ask == 'deadline' else ""}
                    """
                else:
                    # First question - no info collected yet
                    prompt = f"""
                    The user wants to post a job but hasn't provided any details yet.
                    Start by asking for the {field_friendly_name}.
                    Be welcoming and friendly. This is the beginning of the job posting process.
                    """
                
                response_text = self.responder.generate_reply(
                    messages=[{"content": prompt, "role": "user"}]
                )
                
                return {
                    "message": response_text,
                    "metadata": {
                        "intent": "hiring",
                        "missing_fields": missing_fields,
                        "collected_fields": cleaned_details
                    }
                }
        
        # All details collected and validated - create ticket
        # Do final deadline validation before creating ticket
        if 'deadline' in cleaned_details and cleaned_details['deadline'] != "NOT_FOUND":
            is_valid, message, parsed_date = parse_and_validate_deadline(cleaned_details['deadline'])
            
            if is_valid:
                # Update with formatted deadline
                cleaned_details['deadline'] = message
            else:
                # This shouldn't happen if validation above worked, but just in case
                logger.error(f"Deadline validation failed at ticket creation: {message}")
                cleaned_details['deadline'] = "NOT_FOUND"
        
        # Create ticket
        ticket_id, success = self.ticket_manager.create_ticket(
            session_id, user_id, cleaned_details
        )
        
        if success:
            # Clear the hiring context after successful ticket creation
            self.session_manager.save_context(session_id, 'hiring_flow', {
                'collected_fields': {},
                'timestamp': datetime.now().isoformat(),
                'cleared': True
            })
            
            # Format the success message
            response_text = f"""🎉 Great! I've successfully created your job posting!

**Ticket ID:** `{ticket_id}`

**Job Summary:**
• **Position:** {cleaned_details['job_title']}
• **Location:** {cleaned_details['location']}
• **Experience:** {cleaned_details['experience_required']}
• **Salary:** {cleaned_details['salary_range']}
• **Type:** {cleaned_details['employment_type']}
• **Deadline:** {cleaned_details['deadline']}

**Description:** {cleaned_details['job_description'][:100]}...

**Required Skills:** {cleaned_details['required_skills']}

Your job posting has been saved and is now pending approval. Once approved by HR, it will be visible on the website.

Is there anything else I can help you with?"""
        else:
            response_text = "I'm sorry, I encountered an error creating your ticket. Please try again or contact support if the issue persists."
        
        return {
            "message": response_text,
            "metadata": {
                "intent": "hiring",
                "action": "ticket_created" if success else "error",
                "ticket_id": ticket_id if success else None
            }
        }
    
    def _handle_greeting(self, user_id: str) -> Dict:
        """Handle greetings"""
        response_text = "Hello there! 👋 Welcome back! I'm ready to help you with your hiring needs. Would you like to post a new job, check your existing postings, or do something else?"
        
        return {
            "message": response_text,
            "metadata": {"intent": "greeting"}
        }
    
    def _handle_general_question(self, session_id: str, user_id: str,
                                message: str, classification: Dict,
                                history: List[Dict]) -> Dict:
        """Handle general questions - IMPROVED VERSION"""
        context = self._build_context(history)
        
        # Check if the question is about approval
        message_lower = message.lower()
        if 'approve' in message_lower:
            response_text = """I understand you want to approve a ticket. As a chatbot, I don't have the ability to approve tickets directly. 

**Ticket Approval Process:**
• Tickets are reviewed and approved by HR administrators
• They will review your posting through the admin panel
• Once approved, your job will be visible on the website
• You'll receive notification when the status changes

The approval process typically takes 1-2 business days. Your ticket is currently in the queue for review.

Is there anything else I can help you with? You can:
• Post another job
• Check your ticket status (say "Show my tickets")
• Get help with other features"""
            
            return {
                "message": response_text,
                "metadata": {"intent": "question", "topic": "approval"}
            }
        
        prompt = f"""
        The user has asked a question about our hiring system. 
        
        Question: {message}
        
        Recent context:
        {context}
        
        Provide a helpful, friendly response. If it's about posting jobs, mention they can say "I want to post a job".
        If it's about checking status, mention they can say "Show my tickets".
        If it's about approval, explain that HR administrators handle approvals through the admin panel.
        Keep the response conversational and helpful.
        """
        
        response_text = self.responder.generate_reply(
            messages=[{"content": prompt, "role": "user"}]
        )
        
        return {
            "message": response_text,
            "metadata": {"intent": "question"}
        }
    
    def _build_context(self, history: List[Dict]) -> str:
        """Build conversation context string"""
        context_parts = []
        for msg in history[-5:]:  # Last 5 messages
            sender = "User" if msg['sender_type'] == 'user' else "Assistant"
            context_parts.append(f"{sender}: {msg['message_content']}")
        return "\n".join(context_parts)
    
    def _build_hiring_context(self, history: List[Dict], current_message: str) -> str:
        """Build context for hiring detail extraction"""
        messages = []
        
        # Include both user and assistant messages for context
        for msg in history:
            if msg['sender_type'] == 'user':
                messages.append(f"User: {msg['message_content']}")
            elif msg['sender_type'] == 'assistant':
                # Include assistant messages to understand what was asked
                messages.append(f"Assistant: {msg['message_content']}")
        
        messages.append(f"User: {current_message}")
        return "\n".join(messages)

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def extract_json_from_text(text: str) -> Optional[Dict]:
    """Extract JSON from text that might contain other content"""
    if not text:
        return None
    
    try:
        # Try direct parsing
        return json.loads(text.strip())
    except:
        # Try to find JSON in the text
        start = text.find('{')
        end = text.rfind('}')
        if start >= 0 and end > start:
            try:
                return json.loads(text[start:end+1])
            except:
                pass
    return None

def parse_and_validate_deadline(deadline_str: str) -> Tuple[bool, str, Optional[datetime]]:
    """
    Parse and validate deadline date string
    Returns: (is_valid, message, parsed_date)
    """
    try:
        # Common date formats to try
        date_formats = [
            '%d-%m-%Y',
            '%d/%m/%Y',
            '%Y-%m-%d',
            '%d-%m-%y',
            '%d/%m/%y',
            '%d %m %Y',
            '%d %B %Y',
            '%B %d %Y',
            '%d-%b-%Y',
        ]
        
        parsed_date = None
        deadline_clean = deadline_str.strip()
        
        # Try each format
        for fmt in date_formats:
            try:
                parsed_date = datetime.strptime(deadline_clean, fmt)
                break
            except ValueError:
                continue
        
        # If no format worked, try dateutil parser
        if parsed_date is None:
            try:
                from dateutil import parser
                parsed_date = parser.parse(deadline_clean, dayfirst=True)
            except:
                return False, "I couldn't understand that date format. Please provide the deadline in DD-MM-YYYY format (e.g., 25-12-2025).", None
        
        # Check if date is in the future
        current_date = datetime.now()
        
        # If the parsed date has no time, set it to end of day
        if parsed_date.hour == 0 and parsed_date.minute == 0:
            parsed_date = parsed_date.replace(hour=23, minute=59, second=59)
        
        if parsed_date <= current_date:
            days_ago = (current_date - parsed_date).days
            if days_ago == 0:
                return False, f"The deadline must be in the future. The date you provided ({deadline_clean}) is today. Please provide a future date.", None
            else:
                return False, f"The deadline must be in the future. The date you provided ({deadline_clean}) was {days_ago} days ago. Please provide a future date.", None
        
        # Check if date is not too far in the future (e.g., more than 2 years)
        max_future_date = current_date + timedelta(days=730)  # 2 years
        if parsed_date > max_future_date:
            return False, f"The deadline seems too far in the future (more than 2 years). Please provide a reasonable deadline date.", None
        
        # Format the date nicely for storage
        formatted_date = parsed_date.strftime('%d-%m-%Y')
        return True, formatted_date, parsed_date
        
    except Exception as e:
        logger.error(f"Error parsing deadline: {e}")
        return False, "I had trouble understanding that date. Please provide the deadline in DD-MM-YYYY format (e.g., 25-12-2025).", None

# ============================================================================
# EXPORT
# ============================================================================

__all__ = ['ChatBotHandler', 'Config']