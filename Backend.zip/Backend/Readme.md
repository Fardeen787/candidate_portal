# start server
python server.py

# start email_process in new terminal
python email_process.py

# start resume_filter in new terminal
python resume_filter.py
